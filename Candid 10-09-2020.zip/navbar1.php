  <!-- main Navbar -->
<div class="sec2" style="background: #094586;">
  <nav class=" navbar navbar-expand-lg  navbar-dark" style="background: #094586;" >
    <div class="container-fluid d-flex justify-content-between">
   <!-- <a class="navbar-brand" href="#"><img src="photos/logocandid.PNG" style="width: 220px; height: 70px;"></a> -->
    <button style="color: #3078c1;" class="navbar-dark navbar-toggler-right navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon">   
    <i class="fa fa-navicon" style="color:#3078c1; font-size:28px;"></i>
</span>
    </button>
  
    <div class="collapse navbar-collapse " id="navbarNavDropdown" style="text-transform: uppercase;margin-left:100px">
      <ul class="navbar-nav">
        <li class="nav-item active p-2 c1">
          <a class="text-light " href="../candid" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'"><i class="fas fa-home"></i> HOME <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light " style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'"  href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            About
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item border-bottom" href="About.php">About</a>
            <a class="dropdown-item" href="About.php#vission">Vission</a>
            <a class="dropdown-item" href="About.php#mission">Mission</a>
            <a class="dropdown-item" href="About.php#why-candid">Why candid</a>
         <!--   <a class="dropdown-item" href="About.php#our-gallery">Our Gallery</a> -->
          </div>
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-book-reader"></i>&nbsp;Courses</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item "  href="#" data-toggle="modal" data-target="#exampleModal"> <i class="fas fa-book-reader"></i>&nbsp;
            Courses </a>
            <!-- <a href="Courses.php" class="dropdown-item border-bottom">All Courses</a>
            <a class="dropdown-item course1" onclick ="cou(1)">ENGINEERING</a>
            <a class="dropdown-item course2" onclick="cou(2)">MEDICAL</a>
            <a class="dropdown-item course3" onclick="cou(3)">FOUNDATIONS</a>
          </div> -->
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-users"></i> Registration</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="s_register/sch_user.php"><i class="fas fa-users"> &nbsp;</i>Scholarship Test</a>
            <a class="dropdown-item" href="s_register/f_user.php"><i class="fas fa-users"> &nbsp;</i>Free Users</a>
            <a class="dropdown-item" href="s_register/pa_user.php"><i class="fas fa-users">&nbsp;</i>Online Course Purchaser</a>
           <!-- <a class="dropdown-item" href="#">Online Course Purchaser</a>-->
          </div>
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-book"></i>&nbsp;Admission</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#"><i class="fas fa-book"></i>&nbsp;Offline Admission</a>
            <a class="dropdown-item" href="s_register/pa_user.php"><i class="fas fa-book"></i>&nbsp;Online Admission</a>
          </div>
        </li>
        <li class="nav-item active p-2 c1">
          <a class="text-light" href="#" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'">Student Zone<span class="sr-only"></span></a>
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Carrer</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#"><i class="fas fa-user"></i>&nbsp;Super Teacher</a>
            <a class="dropdown-item" href="#"><i class="fas fa-user"></i>&nbsp;Marketing Executive</a>
            <a class="dropdown-item" href="#"><i class="fas fa-user"></i>&nbsp;DTP Operator</a>
             <a class="dropdown-item" href="#"><i class="fas fa-user"></i>&nbsp;Office Bearer</a>
          </div>
        </li>
        <li class="nav-item active p-2 c1">
          <a class="text-light" href="#" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'">Teacher Zone<span class="sr-only"></span></a>
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sign-in-alt"></i>&nbsp;Login</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="s_register/f_user.php"><i class="fas fa-sign-in-alt"></i> Free User Login</a>
            <a class="dropdown-item" href="s_register/pa_user.php"><i class="fas fa-sign-in-alt"></i> Paid Student Login</a>
            <a class="dropdown-item" href="#"><i class="fas fa-sign-in-alt"></i> Super Teacher Login</a>
          </div>
        </li>
        <li class="nav-item dropdown p-2 c1">
          <a class="dropdown-toggle text-light" style="color: #3078c1;font-weight:600" onMouseOver="this.style.color='#023669'"
          onMouseOut="this.style.color='#3078c1'" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-address-book"></i>&nbsp;Contact Us</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#"><i class="fas fa-phone-volume"></i> Call Now</a>
            <a class="dropdown-item" href="#"><i class="fab fa-whatsapp"></i> Whatsapp Message</a>
            <a class="dropdown-item" href="index.php#request"><i class="fas fa-reply"></i> Request A Call Back</a>
          </div>
        </li>
        
       <!-- <li class="sss text-primary nav-item dropdown p-2 c1" style="left:250px;top:4px" >
          <div class="container1">
              <input class="sear" type="text" maxlength= "12" placeholder="Search Course" class="searchbar">
              <img class="sear1" src="https://images-na.ssl-images-amazon.com/images/I/41gYkruZM2L.png" alt="search icon" class="button">
            </div>
         </li> -->
      </ul>
    </div>


    </div>
  </nav>
</div>



<!-- Modal -->
<div class="modal fade m-4" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Select Course Related Your Choice</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="outline:none">
          <span aria-hidden="true" >&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="course_taking"></div>
        <form  method="POST" action="courses.php">
          <div class="form-group">
            <label for="course_name">SELECT STREAM:</label>
            <select name="c_stream" id="course_name" class="form-control">
              <option id="1">Choose Stream</option>
                    <?php

                    $sql = "select distinct course_stream from cpost";

                    $res = $ConnectingDB->query($sql);
                    $i=2;
                    while($row = $res->fetch()){
                       
                    ?>

                        <option id="<?php echo$i?>"><?php echo $row['course_stream']; ?> </option>


                    <?php   
                    $i++;            
                    }

                    ?>
            </select>
          </div>
          <div class="form-group">
            <label for="course_title">SELECT COURSE NAME:</label>
            <select name="" id="course_title" class="form-control">
                    <option id="1">Choose Course Name</option>
           
            </select>
           
          </div>
          <div class="form-group">
            <label for="course_class">SELECT STREAM:</label>
            <select name="" id="course_class" class="form-control">
              <option value="1">Choose Course Class</option>
              
      


            </select>
          </div>


       
   
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" name="show_courses" onclick="showcourse()">Show Courses</button>
      </div>
      </form>
      </div>
    </div>
  </div>
</div>

<script src="js/pop3.js"></script>



