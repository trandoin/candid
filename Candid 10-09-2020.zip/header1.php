<!-- some external information in Top Nav -->
<div class="header" >
    <div class="sec1 ">
        <div class="d-flex justify-content-between">
          <div class=" "><h5 class="p-2"><a class="candid_online text-white" href="#">Candid Online</a></h5></div>
          <div class="aa" style="margin-top: 12px;"><h6><a href="#"  class="text-right text-white">Admission Assistance: 9876576598 (9 am to 8 pm) </a></h6></div>
          <div class="" style="margin-top: 2.5px;"><!-- <a href="Login.php"><i class="fa fa-user-circle ic" style="font-size: 24px;" aria-hidden="true"></i></a> --></div>
        </div>
     </div>