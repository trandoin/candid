function fncc(){
document.getElementById('classroomc').style.display='block';
document.getElementById('recordedc').style.display="none";
document.getElementById('onlinec').style.display="none";
};
function fnoc(){
document.getElementById('classroomc').style.display='none';
document.getElementById('recordedc').style.display="none";
document.getElementById('onlinec').style.display="block";
};

function fncn(){
document.getElementById('classroomc').style.display='none';
document.getElementById('recordedc').style.display="block";
document.getElementById('onlinec').style.display="none";
};
function fnmd(){
    document.getElementById('medical').style.display='block'
    document.getElementById('engern').style.display='none'
    document.getElementById('foundation').style.display='none'
}
function fnfd(){
    document.getElementById('medical').style.display='none'
    document.getElementById('engern').style.display='none'
    document.getElementById('foundation').style.display='block'
}
function fnen(){
    document.getElementById('medical').style.display='none'
    document.getElementById('engern').style.display='block'
    document.getElementById('foundation').style.display='none'
}