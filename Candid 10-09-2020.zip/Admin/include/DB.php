<?php 

$DSN = 'mysql:host=localhost;dbname=candid';
$ConnectingDB = new PDO($DSN,'root','');





 ?>