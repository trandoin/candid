<!-- FOOTER --->
<footer class="bg-dark text-white">
	<div class="container">
		<div class="row">
			<div class="col">
			<p class="lead text-center">Theme by | Govind Suman |<span id="year"></span> &copy; .....All right Reserved By <span><a href="index.php">Candid Coaching Insititute</a></span></p>
		</div>
		</div>
	</div>
</footer>