<div style="height: 5px;background: #27aae1;"></div>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
	<div class="container">
		<a href="#" class="navbar-brand">CANDID</a>
		<button class="navbar-toggler" data-toggle="collapse" data-target="#navbarcollapseCMS">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarcollapseCMS">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a href="Dashboard.php" class="nav-link">Dashboard</a>
			</li>
		<!--	<li class="nav-item">
				<a href="#" class="nav-link">Slide Images</a>
			</li>
			<li class="nav-item">
				<a href="#" class="nav-link">Annoucements</a>
			</li>
			<li class="nav-item">
				<a href="#" class="nav-link">News&Events</a>
			</li>
			<li class="nav-item">
				<a href="#" class="nav-link">Currents Offers</a>
			</li>
			<li class="nav-item">
				<a href="#" class="nav-link">Ans & Sol</a>
			</li>
			<li class="nav-item">
				<a href="#" class="nav-link">Our Results</a>
			</li>
			<li class="nav-item">
				<a href="#" class="nav-link">Testinomials</a>
			</li>
			<li class="nav-item">
				<a href="ViewRegisterStudents.php" class="nav-link">Students Registered</a>
			</li>			
			<li class="nav-item">
				<a href="ViewQueries.php" class="nav-link">Talk To Our Expert</a>
			</li>	-->		
		</ul>
		<ul class="navbar-nav ml-auto">
			<li class="nav-item"><a href="Logout.php" class="nav-link text-danger"><i class="fas fa-user-times"></i> Logout</a></li>
		</ul>
		</div>
	</div>
</nav>
<div style="height: 5px;background: #27aae1;"></div> <!--NAV BAR END-->
