<?php 

$DSN = 'mysql:host=localhost;dbname=rabeena';
$ConnectingDB = new PDO($DSN,'root','');

function Redirect_to($New_location){
	header("Location:".$New_location);
	exit();
}

?>