-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2020 at 03:37 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rabeena`
--

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `reserve` (
  `id` int(10) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `mobile` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `category` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `adhar` text NOT NULL,
  `fname` varchar(50) NOT NULL,
  `foccupation` varchar(50) NOT NULL,
  `fmobile` text NOT NULL,
  `mname` varchar(50) NOT NULL,
  `moccupation` varchar(50) NOT NULL,
  `mmobile` text NOT NULL,
  `paddress` text NOT NULL,
  `ppincity` text NOT NULL,
  `pdistrict` varchar(50) NOT NULL,
  `caddress` text NOT NULL,
  `cpincity` text NOT NULL,
  `cdistrict` varchar(50) NOT NULL,
  `stream` varchar(50) NOT NULL,
  `pclass` text NOT NULL,
  `board` varchar(50) NOT NULL,
  `medium` varchar(10) NOT NULL,
  `admissionclass` text NOT NULL,
  `schoolname` varchar(200) NOT NULL,
  `schooladdress` text NOT NULL,
  `appare10thclass` varchar(50) NOT NULL,
  `passingyear10th` varchar(50) NOT NULL,
  `rollno10th` text NOT NULL,
  `marks10th` text NOT NULL,
  `appare12thclass` varchar(50) NOT NULL,
  `passingyear12th` text NOT NULL,
  `rollno12th` text NOT NULL,
  `marks12th` text NOT NULL,
  `photo` varchar(50) NOT NULL,
  `markssheet10th` varchar(50) NOT NULL,
  `markssheet12th` varchar(50) NOT NULL,
  `source` varchar(100) NOT NULL,
  `terms` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`id`, `datetime`, `name`, `gender`, `mobile`, `email`, `dob`, `category`, `country`, `adhar`, `fname`, `foccupation`, `fmobile`, `mname`, `moccupation`, `mmobile`, `paddress`, `ppincity`, `pdistrict`, `caddress`, `cpincity`, `cdistrict`, `stream`, `pclass`, `board`, `medium`, `admissionclass`, `schoolname`, `schooladdress`, `appare10thclass`, `passingyear10th`, `rollno10th`, `marks10th`, `appare12thclass`, `passingyear12th`, `rollno12th`, `marks12th`, `photo`, `markssheet10th`, `markssheet12th`, `source`, `terms`) VALUES
(5, 'July-08-2020  18: 04: 03', 'Dhanwantpal Singh', 'Male', '+919027997165', 'dhanwantpalsingh3@gmail.com', '2020-06-29', 'obc', 'Indian', '123456789', 'Jagpal ', 'Bussinessmen', '23456789', 'Resham Devi', 'dfghj', '2345678', 'Bijnor (UP),India Jalandhar (Punjab),India', 'Jalandhar', 'PB', 'Bijnor (UP),India', 'Bijnor', 'UTTAR PRADESH', 'Medical', '9th', 'CBSE', 'hindi', '9th', 'AGIC', 'Bijnor (UP),India', '', '', '', '', '', '', '', '', 'Mock test question paper.pdf', 'Mock test question paper.pdf', 'Mock test question paper.pdf', 'School', 'agree'),
(6, 'July-08-2020  18: 07: 11', 'Dhanwantpal Singh', 'Male', '+919027997165', 'Abhisheksingla0187@gmail.com', '2020-06-29', 'obc', 'Indian', '23456789', 'Raja Bhaiya', 'Bussinessmen', '2345678', 'Resham Devi', 'dfhgjh', '2345678', 'Bijnor (UP),India', 'Bijnor', 'UTTAR PRADESH', 'Bijnor (UP),India Jalandhar (Punjab),India', 'Jalandhar', 'Punjab', 'Medical', '9th', 'ICSE', 'hindi', '11th', 'AGIC', 'Bijnor (UP),India Jalandhar (Punjab),India', '', '', '', '', '', '', '', '', '18113027 DhanwantpalSingh MSM.pdf', '18113027 DhanwantpalSingh MSM.pdf', '18113027 DhanwantpalSingh MSM.pdf', 'Poster', 'agree'),
(7, 'July-08-2020  19: 06: 21', 'Dhanwantpal Singh', 'Male', '+919027997165', 'dhanwantpalsingh3@gmail.com', '2020-07-05', 'st', 'Indian', '2345678', 'Dhanwantpal Singh', 'Bussinessmen', '32456789', 'Resham Devi', 'dfhgjh', '32456789', 'Bijnor (UP),India Jalandhar (Punjab),India', 'Jalandhar', 'PB', 'Bijnor (UP),India Jalandhar (Punjab),India', 'Jalandhar', 'Punjab', 'Medical', '9th', 'CBSE', 'hindi', '9th', 'AGIC', 'Bijnor (UP),India Jalandhar (Punjab),India', 'Passed', '2015', '150302', '85%', 'Passed', '2017', '170302', '82%', 'Instructions to attempt Question paper.jpg', 'Mock test question paper.pdf', '18113027 DhanwantpalSingh MSM.pdf', 'Internet', 'agree');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reserve`
--
ALTER TABLE `reserve`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reserve`
--
ALTER TABLE `reserve`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
